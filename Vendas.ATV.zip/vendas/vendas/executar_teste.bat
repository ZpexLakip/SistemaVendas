@echo off
echo === EXECUTANDO TESTE DO SISTEMA DE VENDAS ===
echo.

cd /d "%~dp0"

:: Usar Java 25 completo
set "JAVA_HOME=C:\Program Files\Microsoft\jdk-25.0.0.36-hotspot"

echo Limpando classes antigas...
if exist "target\classes\br" rmdir /s /q "target\classes\br" 2>nul
if exist "target\test-classes\br" rmdir /s /q "target\test-classes\br" 2>nul

echo.
echo Compilando com Java 25...
"%JAVA_HOME%\bin\javac.exe" -d "target\classes" src\main\java\br\icev\vendas\excecoes\*.java
"%JAVA_HOME%\bin\javac.exe" -cp "target\classes" -d "target\classes" src\main\java\br\icev\vendas\*.java
"%JAVA_HOME%\bin\javac.exe" -cp "target\classes" -d "target\test-classes" src\test\java\br\icev\vendas\TesteImplementacao.java

echo.
echo Executando teste com Java 25...
echo ================================
"%JAVA_HOME%\bin\java.exe" -cp "target\classes;target\test-classes" br.icev.vendas.TesteImplementacao
echo ================================

echo.
echo Pressione qualquer tecla para sair...
pause > nul