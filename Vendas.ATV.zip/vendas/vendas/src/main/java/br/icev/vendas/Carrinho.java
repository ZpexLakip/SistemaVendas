package br.icev.vendas;

import br.icev.vendas.excecoes.QuantidadeInvalidaException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class Carrinho {
    private final Map<String, Produto> produtos = new HashMap<>();
    private final Map<String, Integer> quantidades = new HashMap<>();
    
    public void adicionar(Produto produto, int quantidade) throws QuantidadeInvalidaException {
        if (quantidade <= 0) {
            throw new QuantidadeInvalidaException("Quantidade deve ser positiva");
        }
        String codigo = produto.getCodigo();
        produtos.put(codigo, produto);
        quantidades.put(codigo, quantidades.getOrDefault(codigo, 0) + quantidade);
    }

    public BigDecimal getSubtotal() {
        BigDecimal subtotal = BigDecimal.ZERO;
        for (Map.Entry<String, Produto> entry : produtos.entrySet()) {
            String codigo = entry.getKey();
            Produto produto = entry.getValue();
            int quantidade = quantidades.get(codigo);
            BigDecimal valorItem = produto.getPrecoUnitario().multiply(new BigDecimal(quantidade));
            subtotal = subtotal.add(valorItem);
        }
        return UtilDinheiro.arredondar2(subtotal);
    }

    public BigDecimal getTotalCom(PoliticaDesconto politica) {
        BigDecimal subtotal = getSubtotal();
        BigDecimal totalComDesconto = politica.aplicar(subtotal);
        // Nunca retornar valor negativo
        if (totalComDesconto.compareTo(BigDecimal.ZERO) < 0) {
            return BigDecimal.ZERO.setScale(2);
        }
        return UtilDinheiro.arredondar2(totalComDesconto);
    }

    public int getTotalItens() {
        return quantidades.values().stream().mapToInt(Integer::intValue).sum();
    }
}
