package br.icev.vendas;

import br.icev.vendas.excecoes.QuantidadeInvalidaException;
import br.icev.vendas.excecoes.SemEstoqueException;
import java.util.HashMap;
import java.util.Map;

public class Estoque {
    private final Map<String, Integer> estoque = new HashMap<>();
    
    public void adicionarEstoque(String codigo, int quantidade) throws QuantidadeInvalidaException {
        if (quantidade <= 0) {
            throw new QuantidadeInvalidaException("Quantidade deve ser positiva");
        }
        estoque.put(codigo, estoque.getOrDefault(codigo, 0) + quantidade);
    }

    public int getDisponivel(String codigo) {
        return estoque.getOrDefault(codigo, 0);
    }

    public void reservar(String codigo, int quantidade)
            throws SemEstoqueException, QuantidadeInvalidaException {
        if (quantidade <= 0) {
            throw new QuantidadeInvalidaException("Quantidade deve ser positiva");
        }
        int disponivel = getDisponivel(codigo);
        if (disponivel < quantidade) {
            throw new SemEstoqueException("Estoque insuficiente para " + codigo);
        }
        estoque.put(codigo, disponivel - quantidade);
    }

    void adicionarProduto(Produto produto, int quantidade) {
        try {
            adicionarEstoque(produto.getCodigo(), quantidade);
        } catch (QuantidadeInvalidaException e) {
            throw new RuntimeException(e);
        }
    }
}
