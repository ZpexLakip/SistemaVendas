package br.icev.vendas;

import br.icev.vendas.excecoes.*;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * Classe de teste para validar toda a implementação do sistema de vendas.
 * Execute este arquivo para verificar se todas as funcionalidades estão corretas.
 */
public class TesteImplementacao {
    
    public static void main(String[] args) {
        System.out.println("=== TESTANDO SISTEMA DE VENDAS ===\n");
        
        try {
            testeProduto();
            testeEstoque();
            testeCarrinho();
            testePedido();
            testeFluxoCompleto();
            
            System.out.println("\n  TODOS OS TESTES PASSARAM COM SUCESSO! ");
            
        } catch (Exception e) {
            System.err.println(" ERRO : " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private static void testeProduto() throws Exception {
        System.out.println("   Testando classe Produto...");
        
        // Teste de criação válida
        Produto produto1 = new Produto("ABC", "Notebook", new BigDecimal("2500.00"));
        assert produto1.getCodigo().equals("ABC");
        assert produto1.getNome().equals("Notebook");
        assert produto1.getPrecoUnitario().equals(new BigDecimal("2500.00"));
        
        // Teste de igualdade por código
        Produto produto2 = new Produto("ABC", "Outro Nome", new BigDecimal("1000.00"));
        assert produto1.equals(produto2);
        assert produto1.hashCode() == produto2.hashCode();
        
        // Teste de preço negativo
        try {
            new Produto("XYZ", "Produto", new BigDecimal("-10.00"));
            throw new AssertionError("IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // Esperado
        }
        
        // Teste de preço nulo
        try {
            new Produto("XYZ", "Produto", null);
            throw new AssertionError("NullPointerException");
        } catch (NullPointerException e) {
            // Esperado
        }
        
        System.out.println("Produto - OK\n");
    }
    
    private static void testeEstoque() throws Exception {
        System.out.println(" Testando classe Estoque...");
        
        Estoque estoque = new Estoque();
        
        // Adicionar estoque
        estoque.adicionarEstoque("PROD-001", 50);
        assert estoque.getDisponivel("PROD-001") == 50;
        
        // Adicionar mais estoque do mesmo produto
        estoque.adicionarEstoque("PROD-001", 25);
        assert estoque.getDisponivel("PROD-001") == 75;
        
        // Reservar estoque
        estoque.reservar("PROD-001", 30);
        assert estoque.getDisponivel("PROD-001") == 45;
        
        // Produto inexistente
        assert estoque.getDisponivel("INEXISTENTE") == 0;
        
        // Teste quantidade inválida
        try {
            estoque.adicionarEstoque("PROD-002", 0);
            throw new AssertionError("QuantidadeInvalidaException");
        } catch (QuantidadeInvalidaException e) {
            // Esperado
        }
        
        try {
            estoque.adicionarEstoque("PROD-002", -5);
            throw new AssertionError("QuantidadeInvalidaException");
        } catch (QuantidadeInvalidaException e) {
            // Esperado
        }
        
        // Teste sem estoque suficiente
        try {
            estoque.reservar("PROD-001", 100);
            throw new AssertionError("SemEstoqueException");
        } catch (SemEstoqueException e) {
            // Esperado
        }
        
        System.out.println("Estoque - OK\n");
    }
    
    private static void testeCarrinho() throws Exception {
        System.out.println(" Testando classe Carrinho...");
        
        Carrinho carrinho = new Carrinho();
        
        // Produtos para teste
        Produto produto1 = new Produto("A", "Produto A", new BigDecimal("10.50"));
        Produto produto2 = new Produto("B", "Produto B", new BigDecimal("25.75"));
        Produto produto3 = new Produto("C", "Produto C", new BigDecimal("1.115")); 
        
        // Adicionar produtos
        carrinho.adicionar(produto1, 2); // 21.00
        carrinho.adicionar(produto2, 1); // 25.75
        carrinho.adicionar(produto3, 3); // 3.345 -> 3.35
        
        // Total: 21.00 + 25.75 + 3.35 = 50.10
        assert carrinho.getSubtotal().equals(new BigDecimal("50.10"));
        assert carrinho.getTotalItens() == 6;
        
        // Testar acúmulo de quantidade mesmo produto
        carrinho.adicionar(produto1, 1); // Mais 1 do produto A
        assert carrinho.getTotalItens() == 7;
        assert carrinho.getSubtotal().equals(new BigDecimal("60.60")); // +10.50
        
        // Teste com desconto
        PoliticaDesconto desconto10porcento = subtotal -> subtotal.multiply(new BigDecimal("0.90"));
        BigDecimal totalComDesconto = carrinho.getTotalCom(desconto10porcento);
        assert totalComDesconto.equals(new BigDecimal("54.54")); // 60.60 * 0.90
        
        // Teste desconto que resulta em valor negativo
        PoliticaDesconto descontoMaluco = subtotal -> new BigDecimal("-100.00");
        BigDecimal totalNegativo = carrinho.getTotalCom(descontoMaluco);
        assert totalNegativo.equals(new BigDecimal("0.00"));
        
        // Teste quantidade inválida
        try {
            carrinho.adicionar(produto1, 0);
            throw new AssertionError("QuantidadeInvalidaException");
        } catch (QuantidadeInvalidaException e) {
            // Esperado
        }
        
        try {
            carrinho.adicionar(produto1, -5);
            throw new AssertionError("QuantidadeInvalidaException");
        } catch (QuantidadeInvalidaException e) {
            // Esperado
        }
        
        System.out.println("Carrinho - OK\n");
    }
    
    private static void testePedido() throws Exception {
        System.out.println(" Testando classe Pedido...");
        
        Map<String, Integer> itens = new HashMap<>();
        itens.put("PROD-001", 2);
        itens.put("PROD-002", 5);
        
        Pedido pedido = new Pedido(itens, new BigDecimal("150.00"), "AUTH-12345", Pedido.Status.PAGO);
        
        assert pedido.getTotalPago().equals(new BigDecimal("150.00"));
        assert pedido.getCodigoAutorizacao().equals("AUTH-12345");
        assert pedido.getStatus() == Pedido.Status.PAGO;
        assert pedido.getQuantidadeItem("PROD-001") == 2;
        assert pedido.getQuantidadeItem("PROD-002") == 5;
        assert pedido.getQuantidadeItem("INEXISTENTE") == 0;
        
        System.out.println(" Pedido - OK\n");
    }
    
    private static void testeFluxoCompleto() throws Exception {
        System.out.println(" Testando fluxo completo de checkout...");
        
        // Setup
        Estoque estoque = new Estoque();
        estoque.adicionarEstoque("NOTEBOOK", 10);
        estoque.adicionarEstoque("MOUSE", 50);
        
        Carrinho carrinho = new Carrinho();
        Produto notebook = new Produto("NOTEBOOK", "Notebook Dell", new BigDecimal("2500.00"));
        Produto mouse = new Produto("MOUSE", "Mouse Logitech", new BigDecimal("150.00"));
        
        carrinho.adicionar(notebook, 1);
        carrinho.adicionar(mouse, 2);
        
        // Total esperado: 2500.00 + (150.00 * 2) = 2800.00
        assert carrinho.getSubtotal().equals(new BigDecimal("2800.00"));
        
        // Aplicar desconto de 10%
        PoliticaDesconto desconto = subtotal -> subtotal.multiply(new BigDecimal("0.90"));
        BigDecimal total = carrinho.getTotalCom(desconto);
        assert total.equals(new BigDecimal("2520.00")); // 2800 * 0.90
        
        // Simular pagamento
        String codigoAuth = "PAY-" + System.currentTimeMillis();
        
        // Simular reserva de estoque
        estoque.reservar("NOTEBOOK", 1);
        estoque.reservar("MOUSE", 2);
        
        // Verificar estoque após reserva
        assert estoque.getDisponivel("NOTEBOOK") == 9;
        assert estoque.getDisponivel("MOUSE") == 48;
        
        // Criar pedido
        Map<String, Integer> itens = new HashMap<>();
        itens.put("NOTEBOOK", 1);
        itens.put("MOUSE", 2);
        
        Pedido pedido = new Pedido(itens, total, codigoAuth, Pedido.Status.PAGO);
        
        // Verificações finais
        assert pedido.getStatus() == Pedido.Status.PAGO;
        assert pedido.getTotalPago().equals(new BigDecimal("2520.00"));
        assert pedido.getQuantidadeItem("NOTEBOOK") == 1;
        assert pedido.getQuantidadeItem("MOUSE") == 2;
        
        System.out.println(" Fluxo Completo - OK\n");
    }
}